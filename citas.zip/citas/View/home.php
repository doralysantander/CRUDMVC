<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="public/home.css" />
    <title>Crud de citas</title>
</head>
<body>
<section class="nav">
        <h1 class='textCrud'>CRUDo CITAS</h1>
            <h3 class="spanHome loader">
                <span class='m'>s</span>
                <span class='m'>o</span>
                <span class='m'>m</span> 
                <span class='m'>o</span>
                <span class='m'>s</span>
                <span class='m'>&nbsp;</span>
                <span class='m'>p</span>
                <span class='m'>r</span>
                <span class='m'>o</span>
                <span class='m'>g</span>
                <span class='m'>r</span>
                <span class='m'>a</span>
                <span class='m'>m</span>
                <span class='m'>a</span>
                <span class='m'>t</span>
                <span class='m'>e</span>
            </h3>   
        </section>
    </div>
</body>
</html>